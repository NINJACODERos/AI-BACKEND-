# Majdoor AI — Real App (APK)

Streamlit se nikal ke ab ye ek real Android app hai. Do parts hain:

1. **backend/** — Python server jo g4f (free LLM) aur ddgs (free search) chalata hai
2. **www/** — animated chat app jo phone pe chalega, backend se baat karega

g4f/ddgs Python packages hain, phone pe direct nahi chal sakte — isliye backend
kahin free pe host karna padega (zaroori step, skip mat karna).

---

## Step 1: Backend free mein deploy kar (Render.com)

1. `backend/` folder ko apne GitHub repo mein daal (ya naya repo bana: `majdoor-ai-backend`)
2. [render.com](https://render.com) pe free account bana, GitHub se connect kar
3. "New Web Service" → apna repo select kar
4. Settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn app:app --host 0.0.0.0 --port $PORT`
   - Free plan select kar
5. Deploy hone ke baad tujhe ek URL milega jaisे `https://majdoor-backend.onrender.com`
   — ye URL save kar le, app mein daalna hai

(Render free tier thoda so jaata hai idle rehne pe, pehla message 30-40 sec le sakta
hai — chinta mat kar, ye normal hai. Chahe to Hugging Face Spaces bhi try kar sakta
hai, wahan sleep nahi hota.)

---

## Step 2: APK banane ke liye Capacitor setup

Apne computer pe ye chahiye: **Node.js** aur **Android Studio** (dono free hain).

```bash
# is majdoor-app folder ke andar:
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio khulega → upar right mein **Build → Build Bundle(s) / APK(s) → Build APK(s)**
click kar. 2-3 min mein `app-debug.apk` ban jayega — file location terminal mein show
hoga (usually `android/app/build/outputs/apk/debug/`).

Wo APK file kisi ko bhi bhej de, "downloadable for all" — install ho jayega
(pehli baar "unknown sources" allow karna padega, normal Android cheez hai).

---

## Step 3: App khol, backend URL daal

App open karne ke baad top-right ⚙ (gear) icon daba, Step 1 wala Render URL paste
kar, Save & Reconnect dabaa. Status dot green ho jayega — ab kaam shuru.

---

## Commands app ke andar

- `img/kutta` → 7 photos dhoondega
- `dd/aaj ka silver price` → DuckDuckGo text search
- `duck/tu kaisa hai` → seedha chat, same LLM
- kuch bhi normal type kar → sarcastic Hinglish jawaab milega

---

## Agar fix karna ho baad mein

- **Frontend badalna hai (design/animation)?** → `www/index.html` edit kar, phir
  `npx cap sync android` chala ke dobara APK banaa.
- **Backend logic badalna hai (jaise koi naya command)?** → `backend/app.py` edit
  kar, GitHub pe push kar, Render khud redeploy kar dega.
- Deployment ka wahi purana issue: file edit karne ke baad **GitHub pe push karna
  mat bhoolna**, warna deployed cheez purani hi rahegi.
